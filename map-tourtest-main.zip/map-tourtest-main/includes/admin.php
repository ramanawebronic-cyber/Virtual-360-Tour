<?php
defined('ABSPATH') or die('No script kiddies please!');

function webronic_virtual_tour_admin_menu() {
    // Main menu item - will show as parent in sidebar
    add_menu_page(
        'WEBRONIC 360 Tour',
        'WEBRONIC 360 Tour',
        'manage_options',
        'webronic-virtual-tour',
        'webronic_virtual_tour_admin_page', // Default page (Manage Tour)
        'dashicons-camera',
        6
    );

    // Manage Tour - first submenu item (this will be the default page)
    add_submenu_page(
        'webronic-virtual-tour',
        'Manage Tour',
        '<span class="dashicons dashicons-admin-settings" style="font-size: 16px; vertical-align: middle; margin-right: 5px;"></span> Manage Tour',
        'manage_options',
        'webronic-virtual-tour',
        'webronic_virtual_tour_admin_page'
    );

    // Settings page
    add_submenu_page(
        'webronic-virtual-tour',
        'Settings',
        '<span class="dashicons dashicons-admin-generic" style="font-size: 16px; vertical-align: middle; margin-right: 5px;"></span> Settings',
        'manage_options',
        'webronic-virtual-tour-settings',
        'webronic_virtual_tour_settings_page'
    );

    // Edit Tour (hidden from sidebar)
    add_submenu_page(
        null,
        'Edit Tour',
        'Edit Tour',
        'manage_options',
        'webronic-virtual-tour-editor',
        'webronic_virtual_tour_editor_page'
    );

    // Upgrade page (hidden from sidebar)
    add_submenu_page(
        null,
        'Upgrade to PRO',
        'Upgrade to PRO',
        'manage_options',
        'webronic-360-pro',
        'webronic_360_pro_upgrade_page'
    );
}

// Add CSS to style the menu icons properly
function webronic_virtual_tour_admin_menu_styles() {
    echo '<style>
        .dashicons-dashicons-admin-generic:before,
        .dashicons-dashicons-admin-settings:before {
            font-family: dashicons !important;
        }
    </style>';
}
add_action('admin_head', 'webronic_virtual_tour_admin_menu_styles');

// Your existing admin_init hook remains the same
add_action('admin_init', function () {
    if (
        isset($_GET['page']) && $_GET['page'] === 'webronic-virtual-tour' &&
        isset($_GET['action']) && $_GET['action'] === 'delete' &&
        isset($_GET['tour_id'])
    ) {
        check_admin_referer('delete_tour_' . $_GET['tour_id']);
        $result = webronic_virtual_tour_delete_tour((int) $_GET['tour_id']);

        set_transient('webronic_tour_deleted_notice', $result !== false ? 'success' : 'error', 60);

        // Redirect BEFORE any output
        wp_safe_redirect(
            add_query_arg('_t', time(), admin_url('admin.php?page=webronic-virtual-tour'))
        );
        exit;
    }
});

