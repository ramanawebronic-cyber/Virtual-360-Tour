<?php
defined('ABSPATH') or die('No script kiddies please!');

function webronic_virtual_tour_admin_page() {
    global $wpdb;

    if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['tour_id'])) {
        check_admin_referer('delete_tour_' . $_GET['tour_id']);
        $result = webronic_virtual_tour_delete_tour((int) $_GET['tour_id']);
        set_transient('webronic_tour_deleted_notice', $result !== false ? 'success' : 'error', 60);
        wp_redirect(admin_url('admin.php?page=webronic-virtual-tour'));
        exit;
    }

    $notice = get_transient('webronic_tour_deleted_notice');
    if ($notice) {
        echo $notice === 'success'
            ? '<div class="notice notice-success is-dismissible"><p>Tour deleted successfully!</p></div>'
            : '<div class="notice notice-error is-dismissible"><p>Error deleting tour.</p></div>';
        delete_transient('webronic_tour_deleted_notice');
    }

    $tours          = webronic_virtual_tour_get_tours();
    $tour_count     = count($tours);

    // Use premium class to check user status
    $is_pro_user    = webronic_360_is_pro();
    $user_status    = webronic_360_get_user_status(); 
    $can_create_tour = webronic_360_can_create_tour($tour_count);

    // Enqueue admin styles and scripts
    wp_enqueue_style(
        'webronic-virtual-tour-admin-css',
        WEBRONIC_VIRTUAL_TOUR_PLUGIN_URL . 'assets/css/admin.css',
        [],
        WEBRONIC_VIRTUAL_TOUR_VERSION
    );

    // Enqueue upgrade popup styles and scripts
    wp_enqueue_style(
        'webronic-upgrade-popup-css',
        WEBRONIC_VIRTUAL_TOUR_PLUGIN_URL . 'assets/css/upgrade-popup.css',
        [],
        WEBRONIC_VIRTUAL_TOUR_VERSION
    );

    wp_enqueue_script(
        'webronic-virtual-tour-admin-js',
        WEBRONIC_VIRTUAL_TOUR_PLUGIN_URL . 'assets/js/admin.js',
        ['jquery'],
        WEBRONIC_VIRTUAL_TOUR_VERSION,
        true
    );

    wp_enqueue_script(
        'webronic-upgrade-popup-js',
        WEBRONIC_VIRTUAL_TOUR_PLUGIN_URL . 'assets/js/upgrade-popup.js',
        ['jquery'],
        WEBRONIC_VIRTUAL_TOUR_VERSION,
        true
    );

    // Pass data to JavaScript
    wp_localize_script('webronic-virtual-tour-admin-js', 'webronic_virtual_tour_admin', [
        'ajaxurl'        => admin_url('admin-ajax.php'),
        'nonce'          => wp_create_nonce('webronic_virtual_tour_nonce'),
        'is_pro_user'    => $is_pro_user,
        'user_status'    => $user_status,
        'can_create_tour'=> $can_create_tour,
        'tour_count'     => $tour_count,
        'max_free_tours' => 1,
    ]);

    // Icon paths
    $edit_icon_url   = WEBRONIC_VIRTUAL_TOUR_PLUGIN_URL . 'assets/img/edit.png';
    $delete_icon_url = WEBRONIC_VIRTUAL_TOUR_PLUGIN_URL . 'assets/img/delete.png';
    $copy_icon_url   = WEBRONIC_VIRTUAL_TOUR_PLUGIN_URL . 'assets/img/copy.png';
    $pro_icon_url    = WEBRONIC_VIRTUAL_TOUR_PLUGIN_URL . 'assets/img/pro.png';
    $pro2_icon_url   = WEBRONIC_VIRTUAL_TOUR_PLUGIN_URL . 'assets/img/pro2.png';
    ?>

    <div class="wrap">
        <!-- Header: Title left + Add button right -->
        <div class="webronic-header">
            <h1 class="webronic-main-title">
                Webronic 360 Tour
                <?php if ($is_pro_user): ?>
                    <span class="pro-badge">
                        <img src="<?php echo esc_url($pro_icon_url); ?>" alt="Pro" class="pro-badge-icon" width="16" height="16" />
                        PRO
                    </span>
                <?php endif; ?>
            </h1>
            <div class="webronic-header-buttons">
                <!-- SHOW UPGRADE BUTTON ONLY FOR NON-PRO USERS -->
                <?php if (!$is_pro_user): ?>
                    <button id="upgrade-btn" class="webronic-upgrade-btn" >
                        <img src="<?php echo esc_url($pro2_icon_url); ?>" alt="Pro" class="pro-icon" width="16" height="16" />
                        Upgrade
                    </button>
                <?php endif; ?>

                <button id="add-new-tour-btn" type="button" class="webronic-add-btn <?php echo !$can_create_tour ? 'is-locked' : ''; ?>"
                    data-is-pro-user="<?php echo $is_pro_user ? '1' : '0'; ?>"
                    data-can-create-tour="<?php echo $can_create_tour ? '1' : '0'; ?>"
                    aria-disabled="<?php echo !$can_create_tour ? 'true' : 'false'; ?>">
                    <?php if (!$can_create_tour && !$is_pro_user): ?>
                        <img src="<?php echo esc_url($pro_icon_url); ?>" alt="Pro" class="pro-icon" width="16" height="16" />
                    <?php endif; ?>
                    + Add New Tour
                </button>
            </div>
        </div>
        <hr class="wp-header-end">

        <div id="virtual-tour-360-dashboard">
            <?php if (empty($tours)) : ?>
                <!-- No tours state -->
                <?php if ($can_create_tour): ?>
                    <div class="webronic-empty-state">
                        <div class="empty-state-content">
                            <h3>No tours created yet</h3>
                            <p>Click "Add New Tour" to create your first virtual tour.</p>
                        </div>
                    </div>
                <?php endif; ?>
            <?php else : ?>
                <div class="webronic-table-container">
                    <table class="wp-list-table widefat fixed striped table-view-list webronic-tours-table">
                        <thead>
                            <tr>
                                <th scope="col" class="manage-column column-id">Tour ID</th>
                                <th scope="col" class="manage-column column-title">Tour Name</th>
                                <th scope="col" class="manage-column column-shortcode">Embed code</th>
                                <th scope="col" class="manage-column column-scenes">Scenes</th>
                                <th scope="col" class="manage-column column-hotspots">Hotspots</th>
                                <th scope="col" class="manage-column column-date">Created on</th>
                                <th scope="col" class="manage-column column-actions">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $count = 1;
                            foreach ($tours as $tour) :
                                $scene_count   = webronic_virtual_tour_count_scenes($tour->id);
                                $hotspot_count = webronic_virtual_tour_count_hotspots($tour->id);
                                $row_class    = ($count % 2 == 1) ? 'odd-row' : 'even-row';
                            ?>
                                <tr class="<?php echo esc_attr($row_class); ?>">
                                    <td class="column-id"><strong>#<?php echo esc_html($count++); ?></strong></td>
                                    <td class="column-title">
                                        <strong><?php echo esc_html($tour->tour_title); ?></strong>
                                        <div class="row-actions">
                                            <span class="edit">
                                                <a href="#" class="edit-tour" data-id="<?php echo esc_attr($tour->id); ?>" data-title="<?php echo esc_attr($tour->tour_title); ?>">Edit</a> |
                                            </span>
                                            <span class="trash">
                                                <a href="<?php echo esc_url(wp_nonce_url(admin_url('admin.php?page=webronic-virtual-tour&action=delete&tour_id=' . $tour->id), 'delete_tour_' . $tour->id)); ?>"
                                                   class="submitdelete">Delete</a>
                                            </span>
                                        </div>
                                    </td>
                                    <td class="column-shortcode">
                                        <div class="shortcode-container">
                                            <div class="shortcode-input-wrapper">
                                                <input type="text" class="shortcode-input" value="<?php echo esc_attr($tour->shortcode); ?>" readonly>
                                                <button class="copy-shortcode copy-btn" title="Copy Shortcode">
                                                    <img src="<?php echo esc_url($copy_icon_url); ?>" alt="Copy" class="copy-icon" width="20" height="20" />
                                                </button>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="column-scenes"><strong><?php echo esc_html($scene_count); ?></strong></td>
                                    <td class="column-hotspots"><strong><?php echo esc_html($hotspot_count); ?></strong></td>
                                    <td class="column-date">
                                        <strong>
                                            <?php
                                            $created_raw = isset($tour->created_at) ? (string) $tour->created_at : '';

                                            if ($created_raw !== '') {
                                                $ts_utc = strtotime($created_raw . ' UTC');
                                                echo esc_html(
                                                    wp_date(
                                                        get_option('date_format') . ' ' . get_option('time_format'),
                                                        $ts_utc
                                                    )
                                                );
                                            } else {
                                                echo esc_html('-');
                                            }
                                            ?>
                                        </strong>
                                    </td>

                                    <td class="column-actions">
                                        <a class="action-icon img-icon edit-img"
                                           href="<?php echo esc_url(admin_url('admin.php?page=webronic-virtual-tour-editor&tour_id=' . $tour->id)); ?>"
                                           title="Edit Tour" aria-label="Edit Tour">
                                            <img src="<?php echo esc_url($edit_icon_url); ?>" alt="Edit" class="action-icon-img" width="28" height="28" loading="lazy" />
                                        </a>
                                        <a class="action-icon img-icon delete-img submitdelete"
                                           href="<?php echo esc_url(wp_nonce_url(admin_url('admin.php?page=webronic-virtual-tour&action=delete&tour_id=' . $tour->id), 'delete_tour_' . $tour->id)); ?>"
                                           title="Delete Tour" aria-label="Delete Tour">
                                            <img src="<?php echo esc_url($delete_icon_url); ?>" alt="Delete" class="action-icon-img action-icon-img--red" width="28" height="28" loading="lazy" />
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>

        <!-- Add Tour Modal -->
        <div id="add-tour-modal" class="virtual-tour-modal" style="display:none;">
            <div class="virtual-tour-modal-content vtt-card">
                <div class="vtt-modal-head">
                    <h2>Add New Tour</h2>
                    <div class="vtt-actions">
                        <button type="button" class="vtt-btn vtt-btn--cancel close-modal">Cancel</button>
                        <button type="submit" form="add-tour-form" class="vtt-btn vtt-btn--save vtt-btn--add">Add</button>
                    </div>
                </div>

                <div class="vtt-modal-body">
                    <form id="add-tour-form">
                        <div class="form-group vtt-field">
                            <label for="tour-title">Tour Name</label>
                            <input type="text" id="tour-title" name="tour_title" required placeholder="Enter Tour Name">
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Edit Tour Modal -->
        <div id="edit-tour-modal" class="virtual-tour-modal" style="display:none;">
            <div class="virtual-tour-modal-content vtt-card">
                <div class="vtt-modal-head">
                    <h2>Edit Tour</h2>
                    <div class="vtt-actions">
                        <button type="button" class="vtt-btn vtt-btn--cancel close-modal">Cancel</button>
                        <button type="submit" form="edit-tour-form" class="vtt-btn vtt-btn--save">Save</button>
                    </div>
                </div>

                <div class="vtt-modal-body">
                    <form id="edit-tour-form">
                        <input type="hidden" id="edit-tour-id" name="tour_id" value="">
                        <div class="form-group vtt-field">
                            <label for="edit-tour-title">Tour Name</label>
                            <input type="text" id="edit-tour-title" name="tour_title" required value="">
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Include Upgrade Popup -->
        <?php include_once WEBRONIC_VIRTUAL_TOUR_PLUGIN_DIR . 'templates/upgrade-popup.php'; ?>
    </div>
    <?php
}
