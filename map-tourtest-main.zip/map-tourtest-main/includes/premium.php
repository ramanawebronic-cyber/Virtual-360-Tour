<?php
// premium.php - Centralized premium features management

if (!defined('ABSPATH')) {
    exit;
}

class Webronic_360_Premium {

    private static $instance = null;

    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        // Future init
    }

    /**
     * Check if user has premium version
     * Now checks license manager status
     */
    public function is_premium() {
        // Check if license manager exists
        if (class_exists('Webronic_360_License_Manager')) {
            $license_manager = Webronic_360_License_Manager::instance();
            return $license_manager->is_valid();
        }
        
        // Fallback to checking option
        return get_option('webronic_360_user_status', 0) === 1;
    }

    /**
     * Set user status (called by license manager)
     */
    public function set_user_status($status) {
        update_option('webronic_360_user_status', $status, false);
        
        // Log the change
        if (defined('WP_DEBUG') && WP_DEBUG === true) {
            error_log('[WEBRONIC 360 PREMIUM] User status changed to: ' . ($status === 1 ? 'PRO' : 'FREE'));
        }
    }

    /**
     * Get user status
     */
    public function get_user_status() {
        // Check license manager first
        if (class_exists('Webronic_360_License_Manager')) {
            $license_manager = Webronic_360_License_Manager::instance();
            return $license_manager->is_valid() ? 1 : 0;
        }
        
        return get_option('webronic_360_user_status', 0);
    }

    /**
     * Get tour limit based on premium status
     */
    public function get_tour_limit() {
        return $this->is_premium() ? -1 : 1;
    }

    /**
     * Get scene limit based on premium status
     */
    public function get_scene_limit() {
        return $this->is_premium() ? -1 : 5;
    }

    /**
     * Get hotspot limit based on premium status
     */
    public function get_hotspot_limit() {
        return $this->is_premium() ? -1 : 5; 
    }

    /**
     * Check if user can create more tours
     */
    public function can_create_tour($current_tour_count) {
        if ($this->is_premium()) return true;
        return $current_tour_count < $this->get_tour_limit();
    }

    /**
     * Check if user can create more scenes
     */
    public function can_create_scene($current_scene_count) {
        if ($this->is_premium()) return true;
        return $current_scene_count < $this->get_scene_limit();
    }

    /**
     * Check if user can create more hotspots
     */
/**
 * Check if user can create more hotspots (per scene)
 */
public function can_create_hotspot($current_hotspot_count, $scene_id = '', $tour_id = 0) {
    if ($this->is_premium()) return true;
    
    // Check using license manager for per-scene limit
    if (class_exists('Webronic_360_License_Manager')) {
        $license_manager = Webronic_360_License_Manager::instance();
        return $license_manager->check_hotspot_limit(true, $scene_id, $tour_id);
    }
    
    // Fallback: check against current count
    return $current_hotspot_count < $this->get_hotspot_limit();
}
    /**
     * Show upgrade popup if limit reached
     */
    public function maybe_show_upgrade_popup($current_count, $limit_type) {
        if ($this->is_premium()) return false;

        $limit = 0;
        switch ($limit_type) {
            case 'tour':
                $limit = $this->get_tour_limit();
                break;
            case 'scene':
                $limit = $this->get_scene_limit();
                break;
            case 'hotspot':
                $limit = $this->get_hotspot_limit();
                break;
        }

        return $current_count >= $limit;
    }
}

/**
 * Helper functions for easy access
 */

function webronic_360_premium() {
    return Webronic_360_Premium::get_instance();
}

function webronic_360_is_pro() {
    return webronic_360_premium()->is_premium();
}

function webronic_360_get_user_status() {
    return webronic_360_premium()->get_user_status();
}

function webronic_360_get_tour_limit() {
    return webronic_360_premium()->get_tour_limit();
}

function webronic_360_get_scene_limit() {
    return webronic_360_premium()->get_scene_limit();
}

function webronic_360_get_hotspot_limit() {
    return webronic_360_premium()->get_hotspot_limit();
}

function webronic_360_can_create_tour($current_count) {
    return webronic_360_premium()->can_create_tour($current_count);
}

function webronic_360_can_create_scene($current_count) {
    return webronic_360_premium()->can_create_scene($current_count);
}

function webronic_360_can_create_hotspot($current_hotspot_count, $scene_id = '', $tour_id = 0) {
    return webronic_360_premium()->can_create_hotspot($current_hotspot_count, $scene_id, $tour_id);
}

function webronic_360_show_upgrade_popup($current_count, $limit_type) {
    return webronic_360_premium()->maybe_show_upgrade_popup($current_count, $limit_type);
}