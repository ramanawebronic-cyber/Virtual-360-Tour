<?php
function webronic_virtual_tour_settings_page() {
    // Enqueue settings styles and scripts
    wp_enqueue_style(
        'webronic-virtual-tour-settings-css',
        WEBRONIC_VIRTUAL_TOUR_PLUGIN_URL . 'assets/css/settings.css',
        [],
        WEBRONIC_VIRTUAL_TOUR_VERSION
    );
    
    wp_enqueue_script(
        'webronic-virtual-tour-settings-js',
        WEBRONIC_VIRTUAL_TOUR_PLUGIN_URL . 'assets/js/settings.js',
        ['jquery'],
        WEBRONIC_VIRTUAL_TOUR_VERSION,
        true
    );
    
    // Localize script for AJAX and URLs
    wp_localize_script(
        'webronic-virtual-tour-settings-js',
        'webronic_settings',
        [
            'ajax_url' => admin_url('admin-ajax.php'),
            'pro_page_url' => admin_url('admin.php?page=webronic-360-pro'),
            'nonce' => wp_create_nonce('webronic_settings_nonce')
        ]
    );
    
    // Handle license activation
    $activation_message = '';
    $activation_status = '';
    
    if (isset($_POST['webronic_activate_license']) && check_admin_referer('webronic_license_action', 'webronic_license_nonce')) {
        $license_key = sanitize_text_field($_POST['license_key']);
        $email = isset($_POST['license_email']) ? sanitize_email($_POST['license_email']) : '';
        
        if (!empty($license_key)) {
            // Activate the license
            $license_manager = Webronic_360_License_Manager::instance();
            $result = $license_manager->activate($license_key, $email);
            
            if (is_wp_error($result)) {
                $activation_status = 'error';
                $activation_message = $result->get_error_message();
            } else {
                $activation_status = 'success';
                $activation_message = 'License activated successfully!';
            }
        } else {
            $activation_status = 'error';
            $activation_message = 'Please enter a valid license key.';
        }
    }
    
    // Handle license deactivation
    if (isset($_POST['webronic_deactivate_license']) && check_admin_referer('webronic_license_action', 'webronic_license_nonce')) {
        $license_key = sanitize_text_field($_POST['deactivate_license_key']);
        
        if (!empty($license_key)) {
            $license_manager = Webronic_360_License_Manager::instance();
            $result = $license_manager->deactivate_by_key($license_key);
            
            if (is_wp_error($result)) {
                $activation_status = 'error';
                $activation_message = $result->get_error_message();
            } else {
                $activation_status = 'success';
                $activation_message = 'License deactivated successfully!';
            }
        } else {
            $activation_status = 'error';
            $activation_message = 'Please enter a license key to deactivate.';
        }
    }
    
    // Get active tab
    $active_tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : 'general';
    
    // Get user status from premium class
    $is_pro = webronic_360_is_pro();
    $license_manager = Webronic_360_License_Manager::instance();
    $license_info = $license_manager->get_license_info();
    ?>
    <div class="wrap">
        <!-- Header with title and documentation button -->
        <div class="webronic-settings-header">
            <h1 class="webronic-settings-title">
                Webronic 360 Tour Settings
            </h1>
            <a href="#" class="webronic-documentation-btn">
                <img src="<?php echo WEBRONIC_VIRTUAL_TOUR_PLUGIN_URL . 'assets/img/doc.png'; ?>" alt="Documentation" class="doc-icon">
                Documentation
            </a>
        </div>
        
        <hr class="wp-header-end">
        
        <!-- Display activation/deactivation message -->
        <?php if (!empty($activation_message)): ?>
            <div class="notice notice-<?php echo $activation_status === 'success' ? 'success' : 'error'; ?> is-dismissible">
                <p><?php echo esc_html($activation_message); ?></p>
            </div>
        <?php endif; ?>
        
        <div class="webronic-settings-content">
            <!-- Menu Card -->
            <div class="webronic-settings-card webronic-menu-card">
                <nav class="webronic-settings-nav">
                    <ul>
                        <li>
                            <a href="?page=webronic-virtual-tour-settings&tab=general" class="<?php echo $active_tab == 'general' ? 'active' : ''; ?>">
                                <span class="dashicons dashicons-admin-settings"></span>
                                General
                            </a>
                        </li>
                        <li>
                            <a href="?page=webronic-virtual-tour-settings&tab=license" class="<?php echo $active_tab == 'license' ? 'active' : ''; ?>">
                                <span class="dashicons dashicons-admin-network"></span>
                                License!
                            </a>
                        </li>
                    </ul>
                </nav>
            </div>
            
            <!-- Details Card -->
            <div class="webronic-settings-card webronic-details-card">
                <?php if ($active_tab == 'general'): ?>
                    <form method="post" action="options.php">
                        <?php
                        settings_fields('webronic_virtual_tour_settings');
                        do_settings_sections('webronic-virtual-tour-settings');
                        submit_button('Save Settings');
                        ?>
                    </form>
                <?php elseif ($active_tab == 'license'): ?>
                    <div class="license-cards-container">
                        <?php if ($is_pro): ?>
                            <!-- Pro User Card -->
                            <div class="license-card pro-card">
                                <div class="license-card-header">
                                    <div class="license-status">
                                        <div class="status-section">
                                            <div class="status-badge">
                                                <img src="<?php echo WEBRONIC_VIRTUAL_TOUR_PLUGIN_URL . 'assets/img/green.png'; ?>" alt="Verified" class="status-icon">
                                                <span class="status-text">Status: Active</span>
                                            </div>
                                            <div class="status-description">
                                                You are using the Pro version of Webronic 360 Tour
                                            </div>
                                        </div>
                                        <div class="activation-section">
                                            <div class="activation-label">Activated on:</div>
                                            <div class="activation-date">
                                                <?php 
                                                $last_check = $license_info['last_check'];
                                                if ($last_check) {
                                                    echo esc_html(date('F j, Y \a\t g:i A', $last_check));
                                                } else {
                                                    echo 'N/A';
                                                }
                                                ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="license-card-content">
                                    <div class="license-info-left">
                                        <div class="license-icon">
                                            <img src="<?php echo WEBRONIC_VIRTUAL_TOUR_PLUGIN_URL . 'assets/img/fly2.png'; ?>" alt="Pro Version">
                                        </div>
                                        <div class="license-type">Pro</div>
                                        <div class="license-amount">5$</div>
                                    </div>
                                    <div class="license-info-right">
                                        <ul class="features-list">
                                            <li class="feature-item">
                                                <img src="<?php echo WEBRONIC_VIRTUAL_TOUR_PLUGIN_URL . 'assets/img/verify.png'; ?>" alt="Verified" class="feature-icon">
                                                Unlimited Tours
                                            </li>
                                            <li class="feature-item">
                                                <img src="<?php echo WEBRONIC_VIRTUAL_TOUR_PLUGIN_URL . 'assets/img/verify.png'; ?>" alt="Verified" class="feature-icon">
                                                Unlimited Scenes
                                            </li>
                                            <li class="feature-item">
                                                <img src="<?php echo WEBRONIC_VIRTUAL_TOUR_PLUGIN_URL . 'assets/img/verify.png'; ?>" alt="Verified" class="feature-icon">
                                                Unlimited Hotspots
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        <?php else: ?>
                            <!-- Free User - Show both cards horizontally -->
                            <div class="horizontal-cards-container">
                                <!-- Free Card -->
                                <div class="license-card free-card">
                                    <div class="license-card-header">
                                        <div class="license-status">
                                            <div class="status-section">
                                                <div class="status-badge">
                                                    <img src="<?php echo WEBRONIC_VIRTUAL_TOUR_PLUGIN_URL . 'assets/img/green.png'; ?>" alt="Verified" class="status-icon">
                                                    <span class="status-text" stlye="font-weight:700;">Status: Active</span>
                                                </div>
                                                <div class="status-description">
                                                    You are using the free version of Webronic 360 Tour
                                                </div>
                                            </div>

                             <div class="activation-section">
                                            <div class="activation-label">Activated on:</div>
                                            <div class="activation-date">
                                                <?php 
                                                // For free version, show plugin installation date or current date
                                                $plugin_installed = get_option('webronic_virtual_tour_installed_date');
                                                if (!$plugin_installed) {
                                                    $plugin_installed = current_time('timestamp');
                                                    update_option('webronic_virtual_tour_installed_date', $plugin_installed);
                                                }
                                                echo esc_html(date('F j, Y \a\t g:i A', $plugin_installed));
                                                ?>
                                            </div>
                                        </div>
                                        </div>
                                    </div>
                                    <div class="license-card-content">
                                        <div class="license-info-left">
                                            <div class="license-icon">
                                                <img src="<?php echo WEBRONIC_VIRTUAL_TOUR_PLUGIN_URL . 'assets/img/fly1.png'; ?>" alt="Free Version">
                                            </div>
                                            <div class="license-type">Free</div>
                                            <div class="license-amount">0$</div>
                                        </div>
                                        <div class="license-info-right">
                                            <ul class="features-list">
                                                <li class="feature-item">
                                                    <img src="<?php echo WEBRONIC_VIRTUAL_TOUR_PLUGIN_URL . 'assets/img/verify.png'; ?>" alt="Verified" class="feature-icon">
                                                    1 Tours Only
                                                </li>
                                                <li class="feature-item">
                                                    <img src="<?php echo WEBRONIC_VIRTUAL_TOUR_PLUGIN_URL . 'assets/img/verify.png'; ?>" alt="Verified" class="feature-icon">
                                                    Maximum 5 Scenes per tour
                                                </li>
                                                <li class="feature-item">
                                                    <img src="<?php echo WEBRONIC_VIRTUAL_TOUR_PLUGIN_URL . 'assets/img/verify.png'; ?>" alt="Verified" class="feature-icon">
                                                    Maximum 8 Hotspots per scene
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>

                                <!-- Upgrade to Pro Card -->
                                <div class="license-card upgrade-card">
                                    <div class="license-card-header">
                                        <div class="upgrade-header-content">
                                            <div class="upgrade-text">
                                                Unlock unlimited potential for agencies, photographers, and growing businesses.
                                            </div>
                                            <div>
                                                <button id="webronic-upgrade-to-pro" class="upgrade-to-pro" onclick="window.location.href='http://license.test/checkout/?add-to-cart=63';" style="background: linear-gradient(135deg, #4888E8 0%, rgba(118, 75, 162, 1) 100%); border: none; color: white; padding: 12px 24px; border-radius: 6px; font-weight: 600; font-size: 14px; cursor: pointer; transition: all 0.3s ease; box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3); display: flex; align-items: center; gap: 8px;">
                                                    <img src="<?php echo WEBRONIC_VIRTUAL_TOUR_PLUGIN_URL . 'assets/img/pro2.png'; ?>" alt="Pro" style="width: 16px; height: 16px;">
                                                    Upgrade to Pro
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="license-card-content">
                                        <div class="license-info-left">
                                            <div class="license-icon">
                                                <img src="<?php echo WEBRONIC_VIRTUAL_TOUR_PLUGIN_URL . 'assets/img/fly2.png'; ?>" alt="Pro Version">
                                            </div>
                                            <div class="license-type">Pro</div>
                                            <div class="license-amount">5$</div>
                                        </div>
                                        <div class="license-info-right">
                                            <ul class="features-list">
                                                <li class="feature-item">
                                                    <img src="<?php echo WEBRONIC_VIRTUAL_TOUR_PLUGIN_URL . 'assets/img/verify.png'; ?>" alt="Verified" class="feature-icon">
                                                    Unlimited Tours
                                                </li>
                                                <li class="feature-item">
                                                    <img src="<?php echo WEBRONIC_VIRTUAL_TOUR_PLUGIN_URL . 'assets/img/verify.png'; ?>" alt="Verified" class="feature-icon">
                                                    Unlimited Scenes
                                                </li>
                                                <li class="feature-item">
                                                    <img src="<?php echo WEBRONIC_VIRTUAL_TOUR_PLUGIN_URL . 'assets/img/verify.png'; ?>" alt="Verified" class="feature-icon">
                                                    Unlimited Hotspots
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                        
                        <!-- License Management Section - CONDITIONAL DISPLAY -->
                        <div class="license-management-section" style="margin-top: 30px;">
                            
                            <?php if (!$is_pro): ?>
                                <!-- Show ACTIVATE form when license is NOT active -->
                                <div class="license-form-card" style=" width:500px; padding: 25px; background: #fff; border: 1px solid #ddd; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
                                    <h2 style="margin-top: 0; color: #2271b1; font-size: 20px; border-bottom: 2px solid #2271b1; padding-bottom: 10px;">
                                        <span class="dashicons dashicons-yes-alt" style="font-size: 24px; vertical-align: middle;     margin-bottom: 5px;"></span>
                                        Activate License
                                    </h2>
                                    <p style="color: #666; margin-bottom: 20px;">Enter your license key to activate Pro features on this domain.</p>
                                    
                                    <form method="post">
                                        <?php wp_nonce_field('webronic_license_action', 'webronic_license_nonce'); ?>
                                        
                                        <table class="form-table" style="margin-top: 0;">
                                            <tr>
                                                <td style="padding-left: 0;">
                                                    <label for="license_key" style="font-weight: 600; display: block; margin-bottom: 5px;">
                                                        License Key <span style="color: #d63638;">*</span>
                                                    </label>
                                                    <input type="text" 
                                                           id="license_key" 
                                                           name="license_key" 
                                                           class="regular-text" 
                                                           placeholder="WB360-XXXX-XXXX-XXXX-XXXX" 
                                                           style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;"
                                                           required>
                                                    <p class="description" style="margin-top: 5px;">Enter your license key received after purchase</p>
                                                </td>
                                            </tr>
                                        </table>
                                        
                                        <p class="submit" style="margin-top: 20px; padding-top: 20px; border-top: 1px solid #f0f0f0;">
                                            <button type="submit" 
                                                   name="webronic_activate_license" 
                                                   class="button button-primary button-large" 
                                                   style="background: #2271b1; border-color: #2271b1; padding: 8px 20px;">
                                                <span class="dashicons dashicons-yes" style="vertical-align: middle; margin-top: 4px;   margin-bottom: 5px;"></span>
                                                Activate License
                                            </button>
                                        </p>
                                    </form>
                                </div>
                            
                            <?php else: ?>
                                <!-- Show DEACTIVATE form when license IS active -->
                                <div class="license-form-card" style="  width:500px;  padding: 25px; background: #fff; border: 1px solid #ddd; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
                                    <h2 style="margin-top: 0; color: #d63638; font-size: 20px; border-bottom: 2px solid #d63638; padding-bottom: 10px;">
                                        <span class="dashicons dashicons-dismiss" style="font-size: 24px; vertical-align: middle;     margin-bottom: 5px;"></span>
                                        Deactivate License
                                    </h2>
                                    <p style="color: #666; margin-bottom: 20px;">Deactivate your license from this domain to use it on another site.</p>
                                    
                                    <form method="post" onsubmit="return confirm('Are you sure you want to deactivate this license? This will disable Pro features on this site.');">
                                        <?php wp_nonce_field('webronic_license_action', 'webronic_license_nonce'); ?>
                                        
                                        <table class="form-table" style="margin-top: 0;">
                                            <tr>
                                                <td style="padding-left: 0;">
                                                    <label for="deactivate_license_key" style="font-weight: 600; display: block; margin-bottom: 5px;">
                                                        License Key <span style="color: #d63638;">*</span>
                                                    </label>
                                                    <input type="text" 
                                                           id="deactivate_license_key" 
                                                           name="deactivate_license_key" 
                                                           class="regular-text" 
                                                           placeholder="WB360-XXXX-XXXX-XXXX-XXXX" 
                                                           style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;"
                                                           value="<?php echo esc_attr($license_info['license_key']); ?>"
                                                           required>
                                                    <p class="description" style="margin-top: 5px;">Enter the license key to deactivate from this domain</p>
                                                </td>
                                            </tr>
                                        </table>
                                        
                                        <p class="submit" style="margin-top: 20px; padding-top: 20px; border-top: 1px solid #f0f0f0;">
                                            <button type="submit" 
                                                   name="webronic_deactivate_license" 
                                                   class="button button-secondary button-large" 
                                                   style="background: #d63638; border-color: #d63638; color: #fff; padding: 8px 20px;">
                                                <span class="dashicons dashicons-no" style="vertical-align: middle; margin-top: 0px;"></span>
                                                Deactivate License
                                            </button>
                                        </p>
                                    </form>
                                </div>
                            <?php endif; ?>
                            
                        </div>
                        
                        <!-- Help Section -->
                        <div class="help-section" style="margin-top: 30px;">
                            <div class="help-content">
                                <div class="help-text">
                                    <h3>Need Help?</h3>
                                    <p>Need a hand setting up your tour? We've got you covered.</p>
                                </div>
                                <div class="help-buttons">
                                    <button class="help-button">
                                        <img src="<?php echo WEBRONIC_VIRTUAL_TOUR_PLUGIN_URL . 'assets/img/doc2.png'; ?>" alt="Documentation" class="button-icon">
                                        View Documentation
                                    </button>
                                    <button class="help-button">
                                        <img src="<?php echo WEBRONIC_VIRTUAL_TOUR_PLUGIN_URL . 'assets/img/message.png'; ?>" alt="Support" class="button-icon">
                                        Contact Support
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php
}

// Register settings
function webronic_virtual_tour_register_settings() {
    register_setting(
        'webronic_virtual_tour_settings',
        'webronic_virtual_tour_default_settings'
    );

    add_settings_section(
        'webronic_virtual_tour_general_section',
        'General Settings',
        'webronic_virtual_tour_general_section_callback',
        'webronic-virtual-tour-settings'
    );

    add_settings_field(
        'webronic_default_auto_rotate',
        'Default Auto Rotate',
        'webronic_default_auto_rotate_callback',
        'webronic-virtual-tour-settings',
        'webronic_virtual_tour_general_section'
    );

    add_settings_field(
        'webronic_default_zoom_level',
        'Default Zoom Level',
        'webronic_default_zoom_level_callback',
        'webronic-virtual-tour-settings',
        'webronic_virtual_tour_general_section'
    );
}

function webronic_virtual_tour_general_section_callback() {
    echo '<p>Configure the default settings for your virtual tours.</p>';
}

function webronic_default_auto_rotate_callback() {
    $options = get_option('webronic_virtual_tour_default_settings');
    $value = isset($options['auto_rotate']) ? $options['auto_rotate'] : 'false';
    ?>
    <select name="webronic_virtual_tour_default_settings[auto_rotate]">
        <option value="true" <?php selected($value, 'true'); ?>>Enabled</option>
        <option value="false" <?php selected($value, 'false'); ?>>Disabled</option>
    </select>
    <p class="description">Enable auto-rotation for new tours by default.</p>
    <?php
}

function webronic_default_zoom_level_callback() {
    $options = get_option('webronic_virtual_tour_default_settings');
    $value = isset($options['zoom_level']) ? $options['zoom_level'] : '1';
    ?>
    <select name="webronic_virtual_tour_default_settings[zoom_level]">
        <option value="0.5" <?php selected($value, '0.5'); ?>>50%</option>
        <option value="1" <?php selected($value, '1'); ?>>100%</option>
        <option value="1.5" <?php selected($value, '1.5'); ?>>150%</option>
        <option value="2" <?php selected($value, '2'); ?>>200%</option>
    </select>
    <p class="description">Set the default zoom level for new tours.</p>
    <?php
}

// AJAX handler for upgrade redirect
function webronic_handle_upgrade_redirect() {
    // Verify nonce for security
    if (!wp_verify_nonce($_POST['nonce'], 'webronic_settings_nonce')) {
        wp_die('Security check failed');
    }
    
    // Return the pro page URL
    wp_send_json_success([
        'redirect_url' => admin_url('admin.php?page=webronic-360-pro')
    ]);
}
add_action('wp_ajax_webronic_upgrade_redirect', 'webronic_handle_upgrade_redirect');


// Initialize settings
add_action('admin_init', 'webronic_virtual_tour_register_settings');