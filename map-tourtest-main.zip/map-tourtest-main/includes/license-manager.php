<?php
/**
 * License Manager - Secure 7-Layer Protection
 *
 * @package Webronic_360
 * @since 2.0.0
 */

defined('ABSPATH') || exit;

class Webronic_360_License_Manager {
    
    /**
     * License API configuration
     * IMPORTANT: Update these before production!
     */
    private $api_url = 'https://wplicense.webronics.com/';
    private $secret_key = '69131bvva0decc93.71799836';
    private $product_reference = 'webronic-360-pro';
    
    /**
     * Freemium limits
     */
    const FREE_TOUR_LIMIT = 3;
    const FREE_SCENE_LIMIT = 5;
    const FREE_HOTSPOT_LIMIT = 5;
    
    /**
     * Cache duration (12 hours)
     */
    const CACHE_DURATION = 43200;
    
    /**
     * Grace period (7 days)
     */
    const GRACE_PERIOD = 604800;
    
    /**
     * Single instance
     */
    private static $instance = null;
    
    /**
     * Get instance
     */
    public static function instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        $this->init_hooks();
        $this->enable_debug_logging();
    }
    
    /**
     * Enable WordPress debug logging
     */
    private function enable_debug_logging() {
        if (!defined('WP_DEBUG')) {
            define('WP_DEBUG', true);
        }
        if (!defined('WP_DEBUG_LOG')) {
            define('WP_DEBUG_LOG', true);
        }
    }
    
    /**
     * Custom debug log function
     */
    private function debug_log($message, $data = null) {
        if (defined('WP_DEBUG') && WP_DEBUG === true) {
            $log_message = '[WEBRONIC 360 LICENSE] ' . $message;
            
            if ($data !== null) {
                $log_message .= ' | Data: ' . print_r($data, true);
            }
            
            error_log($log_message);
        }
    }
    
    /**
     * Initialize hooks
     */
    private function init_hooks() {
        // License validation hooks
        add_filter('webronic_360_is_pro', array($this, 'is_valid'));
        
        // Limit enforcement hooks
        add_filter('webronic_360_can_create_tour', array($this, 'check_tour_limit'));
        add_filter('webronic_360_can_add_scene', array($this, 'check_scene_limit'), 10, 2);
        add_filter('webronic_360_can_add_hotspot', array($this, 'check_hotspot_limit'), 10, 2);
        
        // Admin notices
        add_action('admin_notices', array($this, 'license_notices'));
    }
    
    // ========================================================================
    // LAYER 1: ENCRYPTED STORAGE
    // ========================================================================
    
    /**
     * Encrypt license key
     */
    private function encrypt($data) {
        if (empty($data)) {
            return '';
        }
        
        $key = $this->get_encryption_key();
        $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length('aes-256-cbc'));
        $encrypted = openssl_encrypt($data, 'aes-256-cbc', $key, 0, $iv);
        
        return base64_encode($encrypted . '::' . $iv);
    }
    
    /**
     * Decrypt license key
     */
    private function decrypt($data) {
        if (empty($data)) {
            return '';
        }
        
        $key = $this->get_encryption_key();
        list($encrypted_data, $iv) = explode('::', base64_decode($data), 2);
        
        return openssl_decrypt($encrypted_data, 'aes-256-cbc', $key, 0, $iv);
    }
    
    /**
     * Get encryption key
     */
    private function get_encryption_key() {
        if (defined('AUTH_KEY') && AUTH_KEY) {
            return substr(hash('sha256', AUTH_KEY), 0, 32);
        }
        return substr(hash('sha256', 'webronic-360-fallback'), 0, 32);
    }
    
    /**
     * Store license key (encrypted)
     */
    private function store_license($license_key, $email = '', $status = 'valid') {
        $this->debug_log('Storing license', array(
            'license_key' => $this->mask_license($license_key),
            'email' => $email,
            'status' => $status
        ));
        
        $encrypted = $this->encrypt($license_key);
        
        update_option('webronic_360_lic_key', $encrypted, false);
        update_option('webronic_360_lic_email', sanitize_email($email), false);
        update_option('webronic_360_lic_status', $status, false);
        update_option('webronic_360_lic_domain', $this->get_domain(), false);
        update_option('webronic_360_lic_last_check', time(), false);
        
        // Update premium status
        if ($status === 'valid') {
            $this->set_premium_status(1); // Pro user
        } else {
            $this->set_premium_status(0); // Free user
        }
        
        // Store integrity hash
        $this->store_integrity_hash($license_key);
        
        // Clear cache
        delete_transient('webronic_360_lic_cache');
    }
    
    /**
     * Get stored license key (decrypted)
     */
    private function get_stored_license() {
        $encrypted = get_option('webronic_360_lic_key', '');
        return $this->decrypt($encrypted);
    }
    
    /**
     * Mask license key for logging
     */
    private function mask_license($license_key) {
        if (empty($license_key) || strlen($license_key) < 12) {
            return '***';
        }
        return substr($license_key, 0, 8) . '****' . substr($license_key, -4);
    }
    
    /**
     * Set premium status
     */
    private function set_premium_status($status) {
        update_option('webronic_360_user_status', $status, false);
        
        // Also update in premium class if available
        if (function_exists('webronic_360_premium')) {
            webronic_360_premium()->set_user_status($status);
        }
        
        $this->debug_log('Premium status updated', array(
            'status' => $status === 1 ? 'PRO' : 'FREE'
        ));
    }
    
    // ========================================================================
    // LAYER 2: INTEGRITY CHECKS
    // ========================================================================
    
    /**
     * Store integrity hash
     */
    private function store_integrity_hash($license_key) {
        $hash = hash_hmac('sha256', $license_key, AUTH_KEY);
        update_option('webronic_360_lic_hash', $hash, false);
    }
    
    /**
     * Verify integrity
     */
    private function verify_integrity() {
        $license_key = $this->get_stored_license();
        $stored_hash = get_option('webronic_360_lic_hash', '');
        
        if (empty($license_key) || empty($stored_hash)) {
            return false;
        }
        
        $computed_hash = hash_hmac('sha256', $license_key, AUTH_KEY);
        return hash_equals($stored_hash, $computed_hash);
    }
    
    // ========================================================================
    // LAYER 3: DOMAIN LOCKING
    // ========================================================================
    
    /**
     * Get current domain
     */
    private function get_domain() {
        $domain = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '';
        $domain = preg_replace('/^www\./', '', $domain);
        return strtolower($domain);
    }
    
    /**
     * Verify domain lock
     */
    private function verify_domain() {
        $activated_domain = get_option('webronic_360_lic_domain', '');
        $current_domain = $this->get_domain();
        
        if (empty($activated_domain)) {
            return true; // First activation
        }
        
        return $activated_domain === $current_domain;
    }
    
    // ========================================================================
    // LAYER 4: REMOTE VALIDATION
    // ========================================================================
    
    /**
     * Remote license check
     */
    private function remote_check($license_key) {
        if (empty($license_key)) {
            $this->debug_log('Remote check failed: No license key provided');
            return array('status' => 'invalid', 'message' => 'No license key provided');
        }
        
        $domain = $this->get_domain();
        
        $api_params = array(
            'slm_action' => 'slm_check',
            'secret_key' => $this->secret_key,
            'license_key' => $license_key,
            'registered_domain' => $domain,
            'item_reference' => $this->product_reference
        );
        
        $this->debug_log('Remote Check - Request Parameters', array(
            'api_url' => $this->api_url,
            'slm_action' => 'slm_check',
            'secret_key' => $this->secret_key,
            'license_key' => $this->mask_license($license_key),
            'registered_domain' => $domain,
            'item_reference' => $this->product_reference
        ));
        
        $response = wp_remote_post(
            $this->api_url,
            array(
                'timeout' => 15,
                'body' => $api_params,
                'sslverify' => false // Set to true in production
            )
        );
        
        if (is_wp_error($response)) {
            $this->debug_log('Remote check - WP Error', array(
                'error_message' => $response->get_error_message(),
                'error_code' => $response->get_error_code()
            ));
            return array(
                'status' => 'error',
                'message' => $response->get_error_message()
            );
        }
        
        $body = wp_remote_retrieve_body($response);
        $this->debug_log('Remote check - Raw Response', $body);
        
        $data = json_decode($body, true);
        
        if (!$data || !isset($data['result'])) {
            $this->debug_log('Remote check - Invalid response structure');
            return array('status' => 'invalid', 'message' => 'Invalid response from server');
        }
        
        $this->debug_log('Remote check - Parsed Response', $data);
        
        return $data;
    }
    
    // ========================================================================
    // LAYER 5: CACHE SYSTEM
    // ========================================================================
    
    /**
     * Get cached license status
     */
    private function get_cached_status() {
        return get_transient('webronic_360_lic_cache');
    }
    
    /**
     * Set cached license status
     */
    private function set_cached_status($status) {
        set_transient('webronic_360_lic_cache', $status, self::CACHE_DURATION);
    }
    
    // ========================================================================
    // LAYER 6: GRACE PERIOD
    // ========================================================================
    
    /**
     * Check grace period
     */
    private function in_grace_period() {
        $last_check = get_option('webronic_360_lic_last_check', 0);
        $last_status = get_option('webronic_360_lic_status', 'invalid');
        
        if ($last_status === 'valid' && (time() - $last_check) < self::GRACE_PERIOD) {
            return true;
        }
        
        return false;
    }
    
    // ========================================================================
    // LAYER 7: SERVER-SIDE VALIDATION
    // ========================================================================
    
    /**
     * Validate license (main method)
     */
    public function is_valid() {
        $this->debug_log('=== LICENSE VALIDATION START ===');
        
        // Check cache first
        $cached = $this->get_cached_status();
        if ($cached !== false) {
            $this->debug_log('Using cached status', array('status' => $cached));
            return $cached === 'valid';
        }
        
        // Get stored license
        $license_key = $this->get_stored_license();
        
        if (empty($license_key)) {
            $this->debug_log('No license key found');
            $this->set_premium_status(0); // Ensure free status
            return false;
        }
        
        $this->debug_log('Found stored license', array('key' => $this->mask_license($license_key)));
        
        // Verify integrity
        if (!$this->verify_integrity()) {
            $this->debug_log('Integrity check failed');
            $this->store_license('', '', 'invalid');
            return false;
        }
        
        $this->debug_log('Integrity check passed');
        
        // Verify domain
        if (!$this->verify_domain()) {
            $this->debug_log('Domain verification failed', array(
                'current_domain' => $this->get_domain(),
                'activated_domain' => get_option('webronic_360_lic_domain', '')
            ));
            $this->set_premium_status(0); // Set to free
            return false;
        }
        
        $this->debug_log('Domain verification passed');
        
        // Remote validation
        $response = $this->remote_check($license_key);
        
        if (isset($response['result']) && $response['result'] === 'success') {
            $this->debug_log('License validation SUCCESS');
            
            // Valid license
            $this->set_cached_status('valid');
            update_option('webronic_360_lic_status', 'valid');
            update_option('webronic_360_lic_last_check', time());
            $this->set_premium_status(1); // Set to pro
            
            if (isset($response['date_expiry'])) {
                update_option('webronic_360_lic_expiry', $response['date_expiry']);
            }
            
            $this->debug_log('=== LICENSE VALIDATION END (VALID) ===');
            return true;
        }
        
        // Check grace period
        if ($this->in_grace_period()) {
            $this->debug_log('Using grace period');
            return true;
        }
        
        // Invalid
        $this->debug_log('License validation FAILED', array('response' => $response));
        $this->set_cached_status('invalid');
        update_option('webronic_360_lic_status', 'invalid');
        $this->set_premium_status(0); // Set to free
        
        $this->debug_log('=== LICENSE VALIDATION END (INVALID) ===');
        return false;
    }
    
    // ========================================================================
    // PUBLIC METHODS
    // ========================================================================
    
    /**
     * Activate license
     */
    public function activate($license_key, $email = '') {
        $this->debug_log('=== LICENSE ACTIVATION START ===');
        
        $license_key = trim($license_key);
        
        if (empty($license_key)) {
            $this->debug_log('Activation failed: Empty license key');
            return new WP_Error('empty_key', 'Please enter a license key');
        }
        
        $domain = $this->get_domain();
        
        // Remote activation
        $api_params = array(
            'slm_action' => 'slm_activate',
            'secret_key' => $this->secret_key,
            'license_key' => $license_key,
            'registered_domain' => $domain,
            'item_reference' => $this->product_reference
        );
        
        $this->debug_log('Activation - Request Parameters', array(
            'api_url' => $this->api_url,
            'slm_action' => 'slm_activate',
            'secret_key' => $this->secret_key,
            'license_key' => $this->mask_license($license_key),
            'registered_domain' => $domain,
            'item_reference' => $this->product_reference
        ));
        
        $response = wp_remote_post(
            $this->api_url,
            array(
                'timeout' => 15,
                'body' => $api_params,
                'sslverify' => false // Set to true in production with valid SSL
            )
        );
        
        if (is_wp_error($response)) {
            $this->debug_log('Activation - WP Error', array(
                'error_message' => $response->get_error_message(),
                'error_code' => $response->get_error_code()
            ));
            return $response;
        }
        
        $body = wp_remote_retrieve_body($response);
        $this->debug_log('Activation - Raw Response', $body);
        
        $data = json_decode($body, true);
        $this->debug_log('Activation - Parsed Response', $data);
        
        if (!$data || !isset($data['result'])) {
            $this->debug_log('Activation - Invalid response structure');
            return new WP_Error('invalid_response', 'Invalid response from license server');
        }
        
        if ($data['result'] === 'success') {
            $this->debug_log('Activation SUCCESS');
            
            // Store license (this will set premium status to 1)
            $this->store_license($license_key, $email, 'valid');
            
            // Define pro constant
            if (!defined('WEBRONIC_360_PRO')) {
                define('WEBRONIC_360_PRO', true);
            }
            
            $this->debug_log('=== LICENSE ACTIVATION END (SUCCESS) ===');
            $this->debug_log('User is now PRO - Status: 1');
            
            return true;
        }
        
        $message = isset($data['message']) ? $data['message'] : 'License activation failed';
        $this->debug_log('Activation FAILED', array('message' => $message));
        $this->debug_log('=== LICENSE ACTIVATION END (FAILED) ===');
        
        return new WP_Error('activation_failed', $message);
    }
    
    /**
     * Deactivate license (using stored license key)
     */
    public function deactivate() {
        $this->debug_log('=== LICENSE DEACTIVATION START (STORED KEY) ===');
        
        $license_key = $this->get_stored_license();
        
        if (empty($license_key)) {
            $this->debug_log('Deactivation failed: No license key found');
            return new WP_Error('no_license', 'No license key found');
        }
        
        return $this->deactivate_by_key($license_key);
    }
    
    /**
     * Deactivate license by providing license key
     * FIXED VERSION - Properly validates license key against stored key
     */
    public function deactivate_by_key($license_key) {
        $this->debug_log('=== LICENSE DEACTIVATION START (BY KEY) ===');
        
        $license_key = trim($license_key);
        
        if (empty($license_key)) {
            $this->debug_log('Deactivation failed: Empty license key provided');
            return new WP_Error('empty_key', 'Please enter a license key');
        }
        
        // Get stored license key to verify
        $stored_license = $this->get_stored_license();
        
        // Verify the provided key matches the stored key
        if ($license_key !== $stored_license) {
            $this->debug_log('Deactivation failed: License key mismatch', array(
                'provided' => $this->mask_license($license_key),
                'stored' => $this->mask_license($stored_license)
            ));
            return new WP_Error('key_mismatch', 'The provided license key does not match the activated license.');
        }
        
        $domain = $this->get_domain();
        
        // Remote deactivation with proper parameters
        $api_params = array(
            'slm_action' => 'slm_deactivate',
            'secret_key' => $this->secret_key,
            'license_key' => $license_key,
            'registered_domain' => $domain,
            'item_reference' => $this->product_reference  // Added this parameter
        );
        
        $this->debug_log('Deactivation - Request Parameters', array(
            'api_url' => $this->api_url,
            'slm_action' => 'slm_deactivate',
            'secret_key' => $this->secret_key,
            'license_key' => $this->mask_license($license_key),
            'registered_domain' => $domain,
            'item_reference' => $this->product_reference
        ));
        
        $response = wp_remote_post(
            $this->api_url,
            array(
                'timeout' => 15,
                'body' => $api_params,
                'sslverify' => false,
                'headers' => array(
                    'Content-Type' => 'application/x-www-form-urlencoded'
                )
            )
        );
        
        if (is_wp_error($response)) {
            $this->debug_log('Deactivation - WP Error', array(
                'error_message' => $response->get_error_message(),
                'error_code' => $response->get_error_code()
            ));
            
            // Clear local license even if remote fails
            $this->clear_license();
            $this->debug_log('Deactivation - Local license cleared despite remote error');
            $this->debug_log('=== LICENSE DEACTIVATION END (LOCAL ONLY) ===');
            
            return new WP_Error('remote_error', 'License deactivated locally, but could not connect to server: ' . $response->get_error_message());
        }
        
        $body = wp_remote_retrieve_body($response);
        $this->debug_log('Deactivation - Raw Response', $body);
        
        $data = json_decode($body, true);
        $this->debug_log('Deactivation - Parsed Response', $data);
        
        // Check if deactivation was successful
        if ($data && isset($data['result'])) {
            if ($data['result'] === 'success') {
                $this->debug_log('Deactivation SUCCESS (remote confirmed)');
                
                // Clear local license
                $this->clear_license();
                
                $this->debug_log('=== LICENSE DEACTIVATION END (SUCCESS) ===');
                $this->debug_log('User is now FREE - Status: 0');
                
                return true;
            } else {
                // API returned error
                $message = isset($data['message']) ? $data['message'] : 'Deactivation failed';
                $this->debug_log('Deactivation FAILED', array('message' => $message));
                
                // Still clear local license for security
                $this->clear_license();
                
                return new WP_Error('deactivation_failed', $message);
            }
        }
        
        // Invalid response structure, but clear local anyway
        $this->debug_log('Deactivation - Invalid response, clearing local');
        $this->clear_license();
        
        $this->debug_log('=== LICENSE DEACTIVATION END (LOCAL CLEARED) ===');
        $this->debug_log('User is now FREE - Status: 0');
        
        return true;
    }
    
    /**
     * Clear license data
     */
    private function clear_license() {
        $this->debug_log('Clearing all license data');
        
        delete_option('webronic_360_lic_key');
        delete_option('webronic_360_lic_email');
        delete_option('webronic_360_lic_status');
        delete_option('webronic_360_lic_domain');
        delete_option('webronic_360_lic_hash');
        delete_option('webronic_360_lic_expiry');
        delete_option('webronic_360_lic_last_check');
        delete_transient('webronic_360_lic_cache');
        
        // Set premium status to 0 (FREE)
        $this->set_premium_status(0);
    }
    
    /**
     * Get license info
     */
    public function get_license_info() {
        $license_key = $this->get_stored_license();
        
        if (empty($license_key)) {
            return array(
                'status' => 'inactive',
                'license_key' => '',
                'email' => '',
                'domain' => '',
                'expiry' => '',
                'user_status' => 0,
                'last_check' => 0
            );
        }
        
        // Return full license key for deactivation form
        $is_valid = $this->is_valid();
        
        return array(
            'status' => $is_valid ? 'active' : 'inactive',
            'license_key' => $license_key,  // Return full key for form
            'masked_key' => $this->mask_license($license_key),  // Masked for display
            'email' => get_option('webronic_360_lic_email', ''),
            'domain' => get_option('webronic_360_lic_domain', ''),
            'expiry' => get_option('webronic_360_lic_expiry', ''),
            'last_check' => get_option('webronic_360_lic_last_check', 0),
            'user_status' => get_option('webronic_360_user_status', 0)
        );
    }
    
    // ========================================================================
    // FREEMIUM LIMITS
    // ========================================================================
    
    /**
     * Check if user can create tour
     */
    public function check_tour_limit($can_create = true) {
        if ($this->is_valid()) {
            return true; // No limit for pro
        }
        
        global $wpdb;
        $table = $wpdb->prefix . 'webronic_virtual_tours';
        $count = $wpdb->get_var("SELECT COUNT(*) FROM $table");
        
        return $count < self::FREE_TOUR_LIMIT;
    }
    
    /**
     * Check if user can add scene
     */
    public function check_scene_limit($can_add = true, $tour_id = 0) {
        if ($this->is_valid()) {
            return true; // No limit for pro
        }
        
        global $wpdb;
        $table = $wpdb->prefix . 'webronic_virtual_tour_scenes';
        $count = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $table WHERE tour_id = %d",
            $tour_id
        ));
        
        return $count < self::FREE_SCENE_LIMIT;
    }
    
    /**
     * Check if user can add hotspot
     * Updated to check per scene limit instead of per tour
     */
    public function check_hotspot_limit($can_add = true, $scene_id = '', $tour_id = 0) {
        if ($this->is_valid()) {
            return true; // No limit for pro
        }
        
        if (empty($scene_id)) {
            return false; // Scene ID required
        }
        
        global $wpdb;
        $table = $wpdb->prefix . 'webronic_virtual_tour_hotspots';
        $count = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $table WHERE tour_id = %d AND scene_id = %s",
            $tour_id,
            $scene_id
        ));
        
        return $count < self::FREE_HOTSPOT_LIMIT;
    }
    
    /**
     * Get current usage
     */
    public function get_usage_stats() {
        global $wpdb;
        
        $tours_table = $wpdb->prefix . 'webronic_virtual_tours';
        $scenes_table = $wpdb->prefix . 'webronic_virtual_tour_scenes';
        $hotspots_table = $wpdb->prefix . 'webronic_virtual_tour_hotspots';
        
        $tour_count = $wpdb->get_var("SELECT COUNT(*) FROM $tours_table");
        $scene_count = $wpdb->get_var("SELECT COUNT(*) FROM $scenes_table");
        $hotspot_count = $wpdb->get_var("SELECT COUNT(*) FROM $hotspots_table");
        
        return array(
            'tours' => array(
                'used' => (int) $tour_count,
                'limit' => $this->is_valid() ? 'unlimited' : self::FREE_TOUR_LIMIT,
                'percentage' => $this->is_valid() ? 0 : ($tour_count / self::FREE_TOUR_LIMIT) * 100
            ),
            'scenes' => array(
                'used' => (int) $scene_count,
                'limit' => $this->is_valid() ? 'unlimited' : 'per tour',
                'note' => $this->is_valid() ? '' : self::FREE_SCENE_LIMIT . ' per tour in free version'
            ),
            'hotspots' => array(
                'used' => (int) $hotspot_count,
                'limit' => $this->is_valid() ? 'unlimited' : 'per scene',
                'note' => $this->is_valid() ? '' : self::FREE_HOTSPOT_LIMIT . ' per scene in free version'
            )
        );
    }
    
    /**
     * Admin notices for license
     */
    public function license_notices() {
        if (!$this->is_valid()) {
            $screen = get_current_screen();
            
            if ($screen && strpos($screen->id, 'webronic-360') !== false) {
                $stats = $this->get_usage_stats();
                
                if ($stats['tours']['used'] >= self::FREE_TOUR_LIMIT) {
                    echo '<div class="notice notice-warning">';
                    echo '<p><strong>WEBRONIC 360:</strong> You have reached the free limit of ' . self::FREE_TOUR_LIMIT . ' tours. ';
                    echo '<a href="' . admin_url('admin.php?page=webronic-virtual-tour-settings&tab=license') . '">Upgrade to Pro</a> for unlimited tours.</p>';
                    echo '</div>';
                }
            }
        }
    }
}