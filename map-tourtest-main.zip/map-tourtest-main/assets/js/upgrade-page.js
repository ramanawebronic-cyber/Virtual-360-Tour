jQuery(document).ready(function ($) {
    // Handle back button click
    $('.back-button').on('click', function() {
        const returnUrl = $(this).data('return-url') || webronic_upgrade.return_url;
        console.log('Redirecting to:', returnUrl); // For debugging
        window.location.href = returnUrl;
    });
    
    // Handle continue for free button click
    $('.free-button').on('click', function() {
        const returnUrl = $(this).data('return-url') || webronic_upgrade.return_url;
        console.log('Redirecting to:', returnUrl); // For debugging
        
        // You can add any free plan activation logic here if needed
        // For now, just redirect back to where they came from
        window.location.href = returnUrl;
    });
    
    // Handle upgrade button click (keep your existing pro button logic)
    $('#pro-upgrade-btn').on('click', function (e) {
        // If you want to handle the pro upgrade with AJAX instead of direct redirect,
        // you can prevent default and use your AJAX logic
        // e.preventDefault();
        // processUpgrade();
        
        // Currently it redirects directly to checkout via onclick
        // So we don't need to prevent default
    });
    
    // AJAX version for actual upgrade processing
    function processUpgrade() {
        $.ajax({
            url: webronic_upgrade.ajaxurl,
            type: 'POST',
            data: {
                action: 'webronic_process_upgrade',
                nonce: webronic_upgrade.nonce,
                plan: 'pro'
            },
            beforeSend: function () {
                $('#upgrade-process').show();
            },
            success: function (response) {
                if (response.success) {
                    $('#upgrade-process').hide();
                    $('#upgrade-success').show();
                    
                    // Update user status globally
                    if (typeof webronic_virtual_tour_admin !== 'undefined') {
                        webronic_virtual_tour_admin.is_pro_user = true;
                        webronic_virtual_tour_admin.user_status = 1;
                    }
                    
                    // Redirect to return URL after successful upgrade
                    setTimeout(function() {
                        window.location.href = webronic_upgrade.return_url;
                    }, 2000);
                } else {
                    alert('Upgrade failed: ' + response.data);
                    $('#upgrade-process').hide();
                }
            },
            error: function () {
                alert('An error occurred during upgrade. Please try again.');
                $('#upgrade-process').hide();
            }
        });
    }
});