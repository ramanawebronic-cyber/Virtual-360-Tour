jQuery(document).ready(function ($) {
  // -----------------------------
  // INIT / STATE
  // -----------------------------
  const isProUser = webronic_virtual_tour_admin.is_pro_user === '1';
  const userStatus = parseInt(webronic_virtual_tour_admin.user_status, 10) || 0;
  const canCreateTour = webronic_virtual_tour_admin.can_create_tour === '1';
  const initialTourCount = parseInt(webronic_virtual_tour_admin.tour_count, 10) || 0;
  const maxFree = parseInt(webronic_virtual_tour_admin.max_free_tours, 10) || 1;

  console.log('User Status:', userStatus, 'Is Pro:', isProUser, 'Can Create Tour:', canCreateTour);

  // Prefer DOM data-flag if present
  const $addBtn = $('#add-new-tour-btn');
  const domIsPro = $addBtn.data('is-pro-user') === '1';
  const domCanCreate = $addBtn.data('can-create-tour') === '1';

  // Ensure ARIA & class reflect current state
  $addBtn
    .attr('aria-disabled', canCreateTour ? 'false' : 'true')
    .toggleClass('is-locked', !canCreateTour);

  // Prevent double submit on "Add"
  let isSubmittingTour = false;

  // -----------------------------
  // OPEN / CLOSE MODALS
  // -----------------------------
  function openModal($m) {
    $m.show();
    $('body').css('overflow', 'hidden');
  }
  function closeAllModals() {
    $('.virtual-tour-modal').hide();
    $('body').css('overflow', 'auto');
  }

  // Add button logic
  $addBtn.on('click', function (e) {
    e.preventDefault();
    
    if (!canCreateTour) {
      // User cannot create more tours → show Upgrade modal
      openModal($('#upgrade-popup-modal'));
      return;
    }
    
    // User can create tours → show Add modal
    $('#tour-title').val('');
    openModal($('#add-tour-modal'));
    $('#tour-title').trigger('focus');
  });

  // Upgrade button - REDIRECT TO PRO PAGE (only shown for non-pro users)
  $('#upgrade-btn').on('click', function () {
window.location.href='https://wplicense.webronics.com/checkout/?add-to-cart=189';  });

  // Card upgrade button in upgrade popup
  $('.card-upgrade-btn').on('click', function () {
    window.location.href = 'admin.php?page=webronic-360-pro';
  });

  // Open Edit modal (row action)
  $(document).on('click', '.edit-tour', function (e) {
    e.preventDefault();
    $('#edit-tour-id').val($(this).data('id'));
    $('#edit-tour-title').val($(this).data('title'));
    openModal($('#edit-tour-modal'));
    $('#edit-tour-title').trigger('focus');
  });

  // Close actions (buttons with .close-modal)
  $(document).on('click', '.close-modal, .button.close-modal', function () {
    closeAllModals();
  });

  // Click outside content to close
  $(window).on('click', function (event) {
    if ($(event.target).is('.virtual-tour-modal')) {
      closeAllModals();
    }
  });

  // Prevent modal content click from bubbling to overlay
  $(document).on('click', '.virtual-tour-modal-content', function (e) {
    e.stopPropagation();
  });

  // -----------------------------
  // ADD TOUR (AJAX)
  // -----------------------------
  $('#add-tour-form')
    .off('submit')
    .on('submit', function (e) {
      e.preventDefault();

      // Double-check creation permission at submit time
      if (!canCreateTour) {
        openModal($('#upgrade-popup-modal'));
        return false;
      }

      if (isSubmittingTour) return;
      isSubmittingTour = true;

      const $submit = $('.vtt-btn--add');
      const origText = $submit.text();
      const title = $('#tour-title').val().trim();

      if (!title) {
        alert('Please enter a tour title');
        isSubmittingTour = false;
        return;
      }

      $submit.prop('disabled', true).text('Adding...');

      $.ajax({
        url: webronic_virtual_tour_admin.ajaxurl,
        type: 'POST',
        data: {
          action: 'webronic_save_tour',
          tour_title: title,
          security: webronic_virtual_tour_admin.nonce,
        },
        success: function (response) {
          if (response && response.success) {
            closeAllModals();
            $('#add-tour-form')[0].reset();

            $('.wrap').prepend(
              '<div class="notice notice-success is-dismissible"><p>' +
                response.data.message +
                '</p></div>'
            );

            // Reload to refresh listing and counts
            setTimeout(function () {
              window.location.reload();
            }, 1000);
          } else {
            const msg =
              (response && response.data && response.data.message) ||
              (response && response.data) ||
              'Failed to create tour.';
            alert('Error: ' + msg);
          }
        },
        error: function (xhr, status, error) {
          const payload =
            (xhr.responseJSON && xhr.responseJSON.data) ||
            ('An error occurred: ' + error);
          alert(payload);
        },
        complete: function () {
          isSubmittingTour = false;
          $submit.prop('disabled', false).text(origText);
        },
      });
    });

  // -----------------------------
  // EDIT TOUR (AJAX)
  // -----------------------------
  $('#edit-tour-form').on('submit', function (e) {
    e.preventDefault();

    const $submit = $('.vtt-btn--save').not('.vtt-btn--add');
    const origText = $submit.text();

    const id = $('#edit-tour-id').val();
    const title = $('#edit-tour-title').val().trim();

    if (!title) {
      alert('Please enter a tour title');
      return;
    }

    $submit.prop('disabled', true).text('Saving...');

    $.ajax({
      url: webronic_virtual_tour_admin.ajaxurl,
      type: 'POST',
      data: {
        action: 'webronic_update_tour',
        tour_id: id,
        tour_title: title,
        security: webronic_virtual_tour_admin.nonce,
      },
      success: function (response) {
        if (response && response.success) {
          window.location.reload();
        } else {
          const msg =
            (response && response.data && response.data.message) ||
            (response && response.data) ||
            'Failed to update tour.';
          alert('Error: ' + msg);
        }
      },
      error: function (xhr, status, error) {
        alert('An error occurred: ' + error);
      },
      complete: function () {
        $submit.prop('disabled', false).text(origText);
      },
    });
  });

  // -----------------------------
  // COPY SHORTCODE
  // -----------------------------
  $(document).on('click', '.copy-shortcode', function (e) {
    e.preventDefault();
    const $btn = $(this);
    const $container = $btn.closest('.shortcode-container');
    const $input = $btn.siblings('.shortcode-input');
    const shortcode = $input.val();

    const $temp = $('<textarea>');
    $('body').append($temp);
    $temp.val(shortcode).select();

    try {
      const ok = document.execCommand('copy');
      if (ok) {
        $btn.addClass('copied');
        $btn.find('.copy-icon').css('filter', 'brightness(0) invert(1)');

        $container.find('.copy-success-message').remove();
        const $msg = $(
          '<div class="copy-success-message">Shortcode copied to clipboard!</div>'
        );
        $container.append($msg);

        setTimeout(function () {
          $msg.fadeOut(300, function () {
            $(this).remove();
          });
        }, 2000);

        setTimeout(function () {
          $btn.removeClass('copied');
          $btn.find('.copy-icon').css('filter', '');
        }, 2000);
      } else {
        $input.select();
        showNotification('Press Ctrl+C to copy the shortcode');
      }
    } catch (err) {
      $input.select();
      showNotification('Press Ctrl+C to copy the shortcode');
    }
    $temp.remove();
  });

  // -----------------------------
  // DELETE CONFIRM
  // -----------------------------
  $(document)
    .off('click', '.submitdelete')
    .on('click', '.submitdelete', function (e) {
      e.preventDefault();
      e.stopImmediatePropagation();

      if (
        !confirm(
          'Are you sure you want to delete this tour? All scenes and hotspots will also be deleted.'
        )
      ) {
        return false;
      }
      window.location.href = $(this).attr('href');
    });

  // -----------------------------
  // NOTIFICATION TOAST
  // -----------------------------
  function showNotification(message) {
    $('.webronic-notice').remove();
    const $notice = $('<div class="webronic-notice">' + message + '</div>');
    $('body').append($notice);
    setTimeout(function () {
      $notice.fadeOut(300, function () {
        $(this).remove();
      });
    }, 3000);
  }

  // -----------------------------
  // RESPONSIVE TABLE
  // -----------------------------
  function adjustTableLayout() {
    const $table = $('.webronic-tours-table');
    if ($(window).width() < 1200) {
      $table.addClass('responsive-mode');
    } else {
      $table.removeClass('responsive-mode');
    }
  }
  $(window).on('resize', adjustTableLayout);
  adjustTableLayout();
});