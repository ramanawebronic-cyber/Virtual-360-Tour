jQuery(document).ready(function ($) {
  // -----------------------------
  // UPGRADE POPUP FUNCTIONALITY
  // -----------------------------

  // Upgrade Now button functionality
// In upgrade-popup.js - update the upgrade button click handler
$('#upgrade-now-btn').on('click', function () {
    // Redirect to the upgrade page
    const upgradeUrl = window.location.origin + '/wp-admin/admin.php?page=webronic-360-pro';
    window.location.href = upgradeUrl;
});

  // Close upgrade popup
  function closeUpgradePopup() {
    $('#upgrade-popup-modal').hide();
    $('body').css('overflow', 'auto');
  }

  // Close button functionality for upgrade popup
  $(document).on('click', '#upgrade-popup-modal .close-modal', function () {
    closeUpgradePopup();
  });

  // Click outside upgrade popup content to close
  $(document).on('click', '#upgrade-popup-modal', function (event) {
    if ($(event.target).is('#upgrade-popup-modal')) {
      closeUpgradePopup();
    }
  });

  // Prevent popup body clicks from bubbling
  $(document).on('click', '#upgrade-popup-modal .virtual-tour-modal-content', function (e) {
    e.stopPropagation();
  });

  // Escape key to close upgrade popup
  $(document).on('keydown', function (e) {
    if (e.keyCode === 27 && $('#upgrade-popup-modal').is(':visible')) {
      closeUpgradePopup();
    }
  });
});
