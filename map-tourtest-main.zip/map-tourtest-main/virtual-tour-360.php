<?php
/*
Plugin Name: WEBRONIC 360 Virtual Tour
Description: Create and manage 360-degree virtual tours independently
Version: 1.0.8
Author: WEBRONIC
*/

defined('ABSPATH') or die('No script kiddies please!');

define('WEBRONIC_VIRTUAL_TOUR_VERSION', '1.0.8');
define('WEBRONIC_VIRTUAL_TOUR_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('WEBRONIC_VIRTUAL_TOUR_PLUGIN_URL', plugin_dir_url(__FILE__));

// Include required files
require_once WEBRONIC_VIRTUAL_TOUR_PLUGIN_DIR . 'includes/database.php';
require_once WEBRONIC_VIRTUAL_TOUR_PLUGIN_DIR . 'includes/admin.php';
require_once WEBRONIC_VIRTUAL_TOUR_PLUGIN_DIR . 'includes/premium.php';
require_once WEBRONIC_VIRTUAL_TOUR_PLUGIN_DIR . 'includes/shortcodes.php';
require_once WEBRONIC_VIRTUAL_TOUR_PLUGIN_DIR . 'includes/editor.php';
require_once WEBRONIC_VIRTUAL_TOUR_PLUGIN_DIR . 'includes/license-manager.php';
require_once WEBRONIC_VIRTUAL_TOUR_PLUGIN_DIR . 'includes/ajax-handlers.php';
require_once WEBRONIC_VIRTUAL_TOUR_PLUGIN_DIR . 'templates/upgrade-page.php';
require_once WEBRONIC_VIRTUAL_TOUR_PLUGIN_DIR . 'includes/settings.php';
require_once WEBRONIC_VIRTUAL_TOUR_PLUGIN_DIR . 'includes/admin-page.php';


// Activation/Deactivation hooks
register_activation_hook(__FILE__, 'webronic_virtual_tour_activate');
register_deactivation_hook(__FILE__, 'webronic_virtual_tour_deactivate');


// Database is create when plugin is activated
function webronic_virtual_tour_activate() {
    webronic_virtual_tour_create_tables();
    if (!get_option('webronic_virtual_tour_version')) {
        update_option('webronic_virtual_tour_version', WEBRONIC_VIRTUAL_TOUR_VERSION);
    }
}

function webronic_virtual_tour_deactivate() {
    // Don't delete tables on deactivation to preserve data
    delete_option('webronic_virtual_tour_version');
}

// Add admin menu
add_action('admin_menu', 'webronic_virtual_tour_admin_menu');

// Initialize the plugin
function webronic_virtual_tour_init() {
    load_plugin_textdomain(
        'webronic-virtual-tour',
        false,
        dirname(plugin_basename(__FILE__)) . '/languages/'
    );
}
add_action('plugins_loaded', 'webronic_virtual_tour_init');
define('MY_GITHUB_TOKEN', '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');

// 🔹 Load the update checker
require_once plugin_dir_path(__FILE__) . 'updater/plugin-update-checker.php';
use YahnisElsts\PluginUpdateChecker\v5\PucFactory;

// 🔹 Initialize update checker
$updateChecker = PucFactory::buildUpdateChecker(
    'https://github.com/Vk2401/map-tourtest',
    __FILE__,
    'map-tourtest'
);
$updateChecker->setBranch('main');
// 🔹 Authenticate for private repo access
$updateChecker->setAuthentication( defined('MY_GITHUB_TOKEN') ? MY_GITHUB_TOKEN : null );

function enqueue_virtual_tour_editor_scripts() {
    wp_enqueue_media();

    wp_enqueue_script(
        'webronic-vt-editor',
        WEBRONIC_VIRTUAL_TOUR_PLUGIN_URL . 'assets/js/editor.js',
        array('jquery'),
        WEBRONIC_VIRTUAL_TOUR_VERSION,
        true
    );

    wp_enqueue_script(
        'webronic-vt-admin',
        WEBRONIC_VIRTUAL_TOUR_PLUGIN_URL . 'assets/js/admin.js',
        array('jquery'),
        WEBRONIC_VIRTUAL_TOUR_VERSION,
        true
    );

    wp_enqueue_script(
        'webronic-vt-viewer',
        WEBRONIC_VIRTUAL_TOUR_PLUGIN_URL . 'assets/js/viewer.js',
        array('jquery'),
        WEBRONIC_VIRTUAL_TOUR_VERSION,
        true
    );

        wp_enqueue_script(
        'webronic-vt-viewer',
        WEBRONIC_VIRTUAL_TOUR_PLUGIN_URL . 'assets/js/upgrade-page.js',
        array('jquery'),
        WEBRONIC_VIRTUAL_TOUR_VERSION,
        true
    );

        wp_enqueue_script(
        'webronic-vt-viewer',
        WEBRONIC_VIRTUAL_TOUR_PLUGIN_URL . 'assets/js/upgrade-popup.js',
        array('jquery'),
        WEBRONIC_VIRTUAL_TOUR_VERSION,
        true
    );

    wp_localize_script('webronic-vt-editor', 'webronicVirtualTour', array(
        'ajaxurl'  => admin_url('admin-ajax.php'),
        'nonce'    => wp_create_nonce('webronic_virtual_tour_nonce'),
        'pluginUrl'=> WEBRONIC_VIRTUAL_TOUR_PLUGIN_URL
    ));

    wp_enqueue_style(
        'webronic-vt-admin-css',
        WEBRONIC_VIRTUAL_TOUR_PLUGIN_URL . 'assets/css/admin.css',
        array(),
        WEBRONIC_VIRTUAL_TOUR_VERSION
    );

    wp_enqueue_style(
        'webronic-vt-editor-css',
        WEBRONIC_VIRTUAL_TOUR_PLUGIN_URL . 'assets/css/editor.css',
        array(),
        WEBRONIC_VIRTUAL_TOUR_VERSION
    );

    wp_enqueue_style(
        'webronic-vt-viewer-css',
        WEBRONIC_VIRTUAL_TOUR_PLUGIN_URL . 'assets/css/viewer.css',
        array(),
        WEBRONIC_VIRTUAL_TOUR_VERSION
    );

        wp_enqueue_style(
        'webronic-vt-viewer-css',
        WEBRONIC_VIRTUAL_TOUR_PLUGIN_URL . 'assets/css/upgrade-popup.css',
        array(),
        WEBRONIC_VIRTUAL_TOUR_VERSION
    );

        wp_enqueue_style(
        'webronic-vt-viewer-css',
        WEBRONIC_VIRTUAL_TOUR_PLUGIN_URL . 'assets/css/upgrade-page.css',
        array(),
        WEBRONIC_VIRTUAL_TOUR_VERSION
    );
}

add_action('admin_enqueue_scripts', 'enqueue_virtual_tour_editor_scripts');
function webronic_virtual_tour_include_template($template_name, $vars = array()) {
    $template_path = WEBRONIC_VIRTUAL_TOUR_PLUGIN_DIR . 'templates/' . $template_name;

    if (file_exists($template_path)) {
        // Extract passed variables into scope
        if (!empty($vars) && is_array($vars)) {
            extract($vars, EXTR_SKIP); // prevents overwriting existing vars
        }

        // Include only once to prevent double rendering
        include_once $template_path;
    } else {
        echo '<div class="error"><p>Template not found: ' . esc_html($template_name) . '</p></div>';
    }
}
