<?php
// Upgrade Popup Modal
$man_icon_url    = WEBRONIC_VIRTUAL_TOUR_PLUGIN_URL . 'assets/img/man.png';
$scene_image_url = WEBRONIC_VIRTUAL_TOUR_PLUGIN_URL . 'assets/img/man.png'; // Add your scene limit image
$hotspot_image_url = WEBRONIC_VIRTUAL_TOUR_PLUGIN_URL . 'assets/img/man.png'; // Add your hotspot limit image
$close_icon_url  = WEBRONIC_VIRTUAL_TOUR_PLUGIN_URL . 'assets/img/cancel.png';
$pro_icon_url    = WEBRONIC_VIRTUAL_TOUR_PLUGIN_URL . 'assets/img/pro.png';
?>
<!-- Upgrade Popup Modal -->
<div id="upgrade-popup-modal" class="virtual-tour-modal" style="display:none;">
    <div class="virtual-tour-modal-content vtt-card" style="width: 550px; max-width: 90%;">
        <div class="vtt-modal-head" style="border-bottom: 1px solid #e1e5ea; padding-bottom: 20px; margin-bottom: 20px;">
            <button type="button" class="close-modal" style="background: none; border: none; cursor: pointer; position: absolute; right: 20px; top: 20px;">
                <img src="<?php echo esc_url($close_icon_url); ?>" alt="Close" width="30" height="30" />
            </button>
        </div>

        <div class="vtt-modal-body" style="text-align: center; padding: 0 30px;">
            <div style="margin-bottom: 24px;">
                <img id="upgrade-popup-image" src="<?php echo esc_url($man_icon_url); ?>" alt="Upgrade" width="300" height="180" style="margin-bottom: 20px;" />
            </div>
            
            <h2 id="upgrade-popup-title" style="color: #4888E8; font-size: 24px; font-weight: 800; margin: 0 0 16px 0; line-height: 1.3;">
                Tour Limit Reached
            </h2>
            
            <p id="upgrade-popup-description" style="color: #000000; font-size: 16px; line-height: 1.5; margin-bottom: 8px;">
                You've created all the tours available on your current plan. Upgrade now to unlock more tours and powerful features to showcase your spaces.
            </p>

            <div class="vtt-actions" style="justify-content: center; gap: 16px; margin-top: 24px;">
                <button type="button" class="webronic-upgrade-popup-btn" id="upgrade-now-btn" onclick="window.location.href='admin.php?page=webronic-360-pro';" style="background: #4888E8; color: #fff; border: none; border-radius: 50px; padding: 12px 24px; font-size: 14px; font-weight: 700; display: flex; align-items: center; justify-content: center; gap: 8px; cursor: pointer; box-shadow: 0 1px 0 rgba(0,0,0,.06); transition: all 0.2s ease; ">
                    <img src="<?php echo esc_url($pro_icon_url); ?>" alt="Pro" width="16" height="16" />
                    Upgrade 
                </button>
            </div>
        </div>
    </div>
</div>

<script>
// Helper function to show upgrade popup with custom content
window.showUpgradePopup = function(type) {
    var title = '';
    var description = '';
    var imageSrc = '<?php echo esc_url($man_icon_url); ?>';
    
    switch(type) {
        case 'tour':
            title = 'Tour Limit Reached';
            description = "You've created all the tours available on your current plan. Upgrade now to unlock more tours and powerful features to showcase your spaces.";
            imageSrc = '<?php echo esc_url($man_icon_url); ?>';
            break;
        case 'scene':
            title = 'Scene Limit Reached';
            description = "You've created all the scenes available on your current plan. Upgrade now to unlock more scenes and powerful features to showcase your spaces.";
            imageSrc = '<?php echo esc_url($scene_image_url); ?>';
            break;
        case 'hotspot':
            title = 'Interactive Pin Limit Reached';
            description = "You've created all the pins available on your current plan. Upgrade now to unlock more pins and powerful features to showcase your spaces.";
            imageSrc = '<?php echo esc_url($hotspot_image_url); ?>';
            break;
        default:
            title = 'Limit Reached';
            description = "You've reached your limit on the current plan. Upgrade now to unlock more features.";
    }
    
    jQuery('#upgrade-popup-title').text(title);
    jQuery('#upgrade-popup-description').text(description);
    jQuery('#upgrade-popup-image').attr('src', imageSrc);
    jQuery('#upgrade-popup-modal').show();
};
</script>