<?php
/**
 * Shortcode to display upgrade/pricing page
 * Usage: [webronic_pricing_plans]
 */
function webronic_pricing_plans_shortcode($atts) {
    // Parse shortcode attributes
    $atts = shortcode_atts([
        'return_url' => '', // Custom return URL after selection
        'show_free' => 'yes', // Show free plan - yes/no
        'show_pro' => 'yes', // Show pro plan - yes/no
    ], $atts);
    
    // Enqueue required styles
    wp_enqueue_style(
        'webronic-upgrade-page-css',
        WEBRONIC_VIRTUAL_TOUR_PLUGIN_URL . 'assets/css/upgrade-page.css',
        [],
        WEBRONIC_VIRTUAL_TOUR_VERSION
    );
    
    // Enqueue required scripts
    wp_enqueue_script(
        'webronic-upgrade-page-js',
        WEBRONIC_VIRTUAL_TOUR_PLUGIN_URL . 'assets/js/upgrade-page.js',
        ['jquery'],
        WEBRONIC_VIRTUAL_TOUR_VERSION,
        true
    );
    
    // Determine return URL
    $return_url = !empty($atts['return_url']) ? $atts['return_url'] : home_url('/');
    
    // Localize script
    wp_localize_script('webronic-upgrade-page-js', 'webronic_upgrade', [
        'ajaxurl' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('webronic_upgrade_nonce'),
        'dashboard_url' => admin_url('admin.php?page=webronic-virtual-tour'),
        'return_url' => esc_url($return_url)
    ]);
    
    // Start output buffering
    ob_start();
    ?>
    
    <div class="webronic-upgrade-page-shortcode">
        <div class="webronic-upgrade-page">
            <!-- Header Section -->
            <div class="webronic-upgrade-header">
                <?php if (!empty($atts['return_url'])): ?>
                <div class="back-button" data-return-url="<?php echo esc_url($return_url); ?>">
                    <img src="<?php echo WEBRONIC_VIRTUAL_TOUR_PLUGIN_URL . 'assets/img/back_to_tour.png'; ?>" alt="Back">
                    <span>Pricing Plans</span>
                </div>
                <?php endif; ?>
                
                <div class="premium-content">
                    <h2>Create a Professional</h2>
                    <h2>360 Map Tours, Simple. Fast.</h2>
                    <p>Pick a plan that fits your goals and start showcasing immersive tours instantly.</p>
                </div>
            </div>

            <!-- Main Content -->
            <div class="webronic-upgrade-content">
                <!-- Upgrade Options -->
                <div class="webronic-upgrade-options">
                    
                    <?php if ($atts['show_free'] === 'yes'): ?>
                    <!-- Free Plan Card -->
                    <div class="upgrade-option-card free-card">
                        <div class="card-image">
                            <img src="<?php echo WEBRONIC_VIRTUAL_TOUR_PLUGIN_URL . 'assets/img/fly1.png'; ?>" alt="Free Plan">
                        </div>
                        <div class="option-header">
                            <h3>Free</h3>
                            <p>Ideal for individuals and small businesses to create a single, impactful tour.</p>
                        </div>
                        <div class="price-section">
                            <div class="price">$0</div>
                            <div class="price-line"></div>
                        </div>
                        <ul class="feature-list">
                            <li>
                                <img src="<?php echo WEBRONIC_VIRTUAL_TOUR_PLUGIN_URL . 'assets/img/verify.png'; ?>" alt="✓">
                                1 Tour Only
                            </li>
                            <li>
                                <img src="<?php echo WEBRONIC_VIRTUAL_TOUR_PLUGIN_URL . 'assets/img/verify.png'; ?>" alt="✓">
                                Maximum 8 Scenes
                            </li>
                            <li>
                                <img src="<?php echo WEBRONIC_VIRTUAL_TOUR_PLUGIN_URL . 'assets/img/verify.png'; ?>" alt="✓">
                                Maximum 5 Hotspots
                            </li>
                        </ul>
                        <div class="button-container">
                            <button class="plan-button free-button" data-return-url="<?php echo esc_url($return_url); ?>">
                                Continue for Free
                            </button>
                        </div>
                    </div>
                    <?php endif; ?>

                    <?php if ($atts['show_pro'] === 'yes'): ?>
                    <!-- Pro Plan Card -->
                    <div class="upgrade-option-card pro-card">
                        <div class="popular-badge">
                            <img src="<?php echo WEBRONIC_VIRTUAL_TOUR_PLUGIN_URL . 'assets/img/most.png'; ?>" alt="Most Popular">
                        </div>
                        <div class="card-image">
                            <img src="<?php echo WEBRONIC_VIRTUAL_TOUR_PLUGIN_URL . 'assets/img/fly2.png'; ?>" alt="Pro Plan">
                        </div>
                        <div class="option-header">
                            <h3>Pro</h3>
                            <p>Unlock unlimited potential for agencies, photographers, and growing businesses.</p>
                        </div>
                        <div class="price-section">
                            <div class="price">$5</div>
                            <div class="price-line"></div>
                        </div>
                        <ul class="feature-list">
                            <li>
                                <img src="<?php echo WEBRONIC_VIRTUAL_TOUR_PLUGIN_URL . 'assets/img/verify.png'; ?>" alt="✓">
                                Unlimited Tours
                            </li>
                            <li>
                                <img src="<?php echo WEBRONIC_VIRTUAL_TOUR_PLUGIN_URL . 'assets/img/verify.png'; ?>" alt="✓">
                                Unlimited Scenes
                            </li>
                            <li>
                                <img src="<?php echo WEBRONIC_VIRTUAL_TOUR_PLUGIN_URL . 'assets/img/verify.png'; ?>" alt="✓">
                                Unlimited Hotspots
                            </li>
                        </ul>
                        <div class="button-container">
                            <button 
                                class="plan-button pro-button" 
                                id="pro-upgrade-btn-shortcode" 
                                onclick="window.location.href='https://wpdemo.webronics.com/checkout/?add-to-cart=189';"
                            >
                                <img 
                                    src="<?php echo WEBRONIC_VIRTUAL_TOUR_PLUGIN_URL . 'assets/img/pro.png'; ?>" 
                                    alt="Pro"
                                >
                                Upgrade to Pro
                            </button>
                        </div>
                    </div>
                    <?php endif; ?>
                    
                </div>
            </div>
        </div>
    </div>
    
    <?php
    // Return the buffered content
    return ob_get_clean();
}

// Register the shortcode
add_shortcode('webronic_pricing_plans', 'webronic_pricing_plans_shortcode');